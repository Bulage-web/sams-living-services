// Simple JavaScript for mobile menu toggle
document.addEventListener('DOMContentLoaded', function() {
  // Mobile menu toggle
  const menuToggle = document.querySelector('.menu-toggle');
  
  if (menuToggle) {
    menuToggle.addEventListener('click', function() {
      // This is just a placeholder for future menu functionality
      console.log('Menu toggle clicked');
    });
  }
  
  // Track button clicks for analytics
  const buttons = document.querySelectorAll('.btn');
  buttons.forEach(button => {
    button.addEventListener('click', function(e) {
      console.log('Button clicked: ' + this.textContent);
      // No need to prevent default as we want the mailto: links to work
    });
  });
});
